# e-commerce-network

this is a simulation of an e-commerce
